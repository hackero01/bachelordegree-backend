﻿using Office03.Models;
using Office03.Servicies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
using static Office03.Models.TeacherModel;

namespace Office03.Controllers
{
    public class TeacherController : ApiController
    {
        [System.Web.Http.HttpGet]
        [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        [System.Web.Http.Route("api/loadAllTeachers")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult loadAllTeachers()
        {

            return Json(TeacherServicies.loadAllTeachers()); // index pags

        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/deleteTeacher")]

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult deleteTeacher([FromBody] TeacherModel teacher)
        {
            TeacherServicies ts = new TeacherServicies();
            ts.deleteTeacher(teacher);
            return Ok();
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/setTeacherCourse")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult setTeacherCourse([FromBody] SetTeacherCourse user)
        {
            TeacherServicies ts = new TeacherServicies();
            ts.setTeacherCourse(user);
            return Ok();
        }
        [System.Web.Http.HttpGet]
        [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        [System.Web.Http.Route("api/getAllCourses")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult getAllCourses()
        {

            return Json(TeacherServicies.getAllCourses());

        }
        [System.Web.Http.HttpGet]
        [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        [System.Web.Http.Route("api/teacherDetails")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult teacherDetails([FromUri] int id)
        {

            return Json(TeacherServicies.teacherDetails(id)); // index pags

        }
    }
    
}
