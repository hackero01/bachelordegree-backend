﻿using System.Web.Http.Cors;
using Office03.Models;
using Office03.Repository;
using Office03.Servicies;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

using static Office03.Models.ModelUtilizatori;
using static Office03.Models.ModelSpecializari;

namespace Office03.Controllers
{
    public class UserController : ApiController
    {
        #region Conectare/deconectare/inregistrare
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/userLogin")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult userLogin(string email, string pass)
        {

            return Ok(UServicies.userLogin(email, pass));

        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/userLogOut")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult userLogOut([FromBody] LogoutModel usr)
        {

            UServicies us = new UServicies();
            us.checkIfConnected(usr.idUtilizator);
            return Ok();

        }
        #endregion
        #region IndexPages
        //[System.Web.Http.HttpGet]
        //[System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        //[System.Web.Http.Route("api/getAllAccounts")]
        //[EnableCors(origins: "*", headers: "*", methods: "*")]


        //public IHttpActionResult getAllAccounts()
        //{

        //    return Json(UServicies.getAllAccounts()); // index pages

        //}
        //[System.Web.Http.HttpGet]
        //[System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        //[System.Web.Http.Route("api/getAllAnnouncement")]
        //[EnableCors(origins: "*", headers: "*", methods: "*")]


        //public IHttpActionResult getAllAnnouncement()
        //{

        //    return Json(UServicies.getAllAnnouncement()); // index pags

        //}
       
       
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/getNumberOfAccounts")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult countAccounts()
        {

            UServicies us = new UServicies();
            int count = 0;
            count=us.countAccounts(count);
            
            return Ok(count);

        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/getNumberOfCourse")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult countCourse()
        {

            UServicies us = new UServicies();
            int count = 0;
            count = us.countCourse(count);

            return Ok(count);

        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/creeazaUser")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult creeazaSpecializare([FromBody] ModelUtilizatori spc)
        {
            UServicies spec = new UServicies();
            spec.creeazaUser(spc);
            return Ok();
        }
        #endregion
        #region userProfile
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/updateData")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult updateData([FromBody] ModelUtilizatori usr)
        {
            UServicies us = new UServicies();
            us.updateData(usr);
            return Ok();
        }

        #endregion
        #region Management Specializari
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/creeazaSpecializare")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult creeazaSpecializare([FromBody] ModelSpecializari spc)
        {
            UServicies spec = new UServicies();
            spec.creeazaSpecializare(spc);
            return Ok();
        }
        [System.Web.Http.HttpGet]
        [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        [System.Web.Http.Route("api/incarcaSpecializare")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult incarcaSpecializare()
        {

            return Json(UServicies.incarcaSpecializare()); // index pags

        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/stergeSpecializare")]
      
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult stergeSpecializare([FromBody] ModelSpecializari spc)
        {
            UServicies spec = new UServicies();
            spec.stergeSpecializare(spc);
            return Ok();
        }
        [System.Web.Http.HttpGet]
        [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        [System.Web.Http.Route("api/detaliiSpecializare")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult detaliiSpecializare([FromUri] int idSpecializare)
        {

            return Json(UServicies.detaliiSpecializari(idSpecializare)); // index pags

        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/editeazaSpecializare")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult modificaSpecializare([FromBody] ModelSpecializari specializare)
        {
            UServicies us = new UServicies();
            us.modificaSpecializare(specializare);
            return Ok();
        }
        #endregion
        #region Management conturi
        [System.Web.Http.HttpGet]
        [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        [System.Web.Http.Route("api/incarcaConturi")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult incarcaConturi()
        {

            return Json(UServicies.incarcaConturi()); // index pags

        }
        [System.Web.Http.HttpGet]
        [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        [System.Web.Http.Route("api/detaliiCont")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult detaliiCont([FromUri] int idUtilizator)
        {

            return Json(UServicies.detaliiCont(idUtilizator)); // index pags

        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/stergeCont")]

        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult stergeCont([FromBody] DeleteModel cont)
        {
            UServicies spec = new UServicies();
            spec.stergeCont(cont);
            return Ok();
        }
        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("api/updateAccountAdmin")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]
        public IHttpActionResult updateAccountsAdmin([FromBody] ModelUtilizatori usr)
        {
            UServicies us = new UServicies();
            us.updateAccountsAdmin(usr);
            return Ok();
        }
        #endregion
        #region management membrii specializari
        [System.Web.Http.HttpGet]
        [System.Web.Script.Services.ScriptMethod(UseHttpGet = true)]
        [System.Web.Http.Route("api/getProfilesMembers")]
        [EnableCors(origins: "*", headers: "*", methods: "*")]


        public IHttpActionResult getProfilesMembers()
        {

            return Json(UServicies.getProfileMembers()); // index pags

        }
        #endregion

    }
}
