﻿using Office03.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using static Office03.Models.TeacherModel;

namespace Office03.Repository
{
    public class TeacherRepository
    {
        private DBConnect db = new DBConnect();
        private SqlCommand cmd;
        private SqlDataReader reader;
      
        public List<TeacherModel> loadAllTeachers()
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<TeacherModel> teacherList = new List<TeacherModel>();
            TeacherModel teacher = null;
            try
            {
                cmd = new SqlCommand(NewQuery.loadAllTeacher, conn);
                // cmd.Parameters.Add(new SqlParameter("username", username));
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        int id = Int32.Parse(reader["id"].ToString());
                        int idUtilizator = Int32.Parse(reader["id_utilizator"].ToString());
                        int idSpecializare = Int32.Parse(reader["id_specializare"].ToString());
                        int idMaterie = Int32.Parse(reader["id_materie"].ToString());
                        string nume = reader["nume"].ToString();
                        string prenume = reader["prenume"].ToString();
                        string numeMaterie = reader["nume_materie"].ToString();
                        string numeSpecializare = reader["nume_specializare"].ToString();
                        teacher = new TeacherModel(id, idUtilizator, idSpecializare, idMaterie, nume, prenume, numeMaterie,numeSpecializare);

                        teacherList.Add(teacher);


                    }

                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return teacherList;


        }
        public void deleteTeacher(TeacherModel tch)
        {

            SqlConnection conn = db.initializare();
            SqlCommand cmd;


            try
            {
                cmd = new SqlCommand(NewQuery.deleteTeacher, conn);
                cmd.Parameters.Add(new SqlParameter("id", tch.id));

                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }



        }
        public string setTeacherCourse(SetTeacherCourse course)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            string mesaj = " ";

            try
            {
                cmd = new SqlCommand(NewQuery.setTeacherCourse, conn);
                cmd.Parameters.Add(new SqlParameter("idMaterie", course.idMaterie));
                cmd.Parameters.Add(new SqlParameter("id", course.id));
                // cmd.Parameters.Add(new SqlParameter("idMaterie", teacher.idMaterie));






                if (cmd.ExecuteNonQuery() == 1)
                {
                    mesaj = "Materie atribuita cu succes";
                }
                else
                {
                    mesaj = "Nu se poate atribuii materia acestui profesor";
                }




            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }

            return mesaj;
        }
        public List<CourseModel> getAllCourses()
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<CourseModel> courseList = new List<CourseModel>();
            CourseModel materie = null;
            try
            {
                cmd = new SqlCommand(NewQuery.getAllCourses, conn);

                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        int idMaterie = Int32.Parse(reader["id_materie"].ToString());
                        string numeMaterie= reader["nume_materie"].ToString();
                        int idSpecializare = Int32.Parse(reader["id_specializare"].ToString());
                        int credite = Int32.Parse(reader["credite"].ToString());
                        int semestru = Int32.Parse(reader["semestru"].ToString());
                        int anStudiu = Int32.Parse(reader["an_studiu"].ToString());
                        int idUtilizator = 0;
                        materie = new CourseModel(idMaterie, numeMaterie, idSpecializare, credite, semestru, anStudiu, idUtilizator);
                        courseList.Add(materie);

                    }

                }


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

             conn.Dispose();
                conn.Close();
            }
            return courseList;

        }
        public TeacherModel teacherDetails(int id)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<TeacherModel> listaDetalii = new List<TeacherModel>();
            TeacherModel teacher = null;
            try
            {
                cmd = new SqlCommand(NewQuery.loadTeacherDetails, conn);
                cmd.Parameters.Add(new SqlParameter("id", id));
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {
                         id = Int32.Parse(reader["id"].ToString());
                        int idUtilizator = Int32.Parse(reader["id_utilizator"].ToString());
                        int idSpecializare = Int32.Parse(reader["id_specializare"].ToString());
                        int idMaterie = Int32.Parse(reader["id_materie"].ToString());
                        string nume = reader["nume"].ToString();
                        string prenume = reader["prenume"].ToString();
                        string numeMaterie = reader["nume_materie"].ToString();
                        string numeSpecializare = reader["nume_specializare"].ToString();
                        teacher = new TeacherModel(id,idUtilizator, idSpecializare, idMaterie, nume, prenume, numeMaterie,numeSpecializare);

                        listaDetalii.Add(teacher);


                    }

                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return teacher;


        }
    }
}