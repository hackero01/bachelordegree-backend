﻿using Office03.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using static Office03.Models.ModelSpecializari;
using static Office03.Models.ModelUtilizatori;

namespace Office03.Repository
{
    public class URepository
    {
        private DBConnect db = new DBConnect();
        private SqlCommand cmd;
        private SqlDataReader reader;

        #region Conectare/Deconectare/Inregistrare
        public ModelUtilizatori checkUserLogin(string email, string pass)
        {

            SqlConnection conn = db.initializare();
            ModelUtilizatori user = null;
            
 
           
            try
            {
                cmd = new SqlCommand(NewQuery.loginCheck, conn);
                cmd.Parameters.Add(new SqlParameter("email", email));
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {
                        int idUtilizator = Int32.Parse(reader["id_utilizator"].ToString());
                        string nume = reader["nume"].ToString();
                        string prenume = reader["prenume"].ToString();
                        email = reader["email"].ToString();
                        string parola = reader["parola"].ToString();
                        string adresa = reader["adresa"].ToString();
                        string numarTelefon = reader["nr_telefon"].ToString();
                       bool conectat = bool.Parse(reader["conectat"].ToString());
                        string statut = reader["statut"].ToString();
                        int idRol = Int32.Parse(reader["id_rol"].ToString());
                        user = new ModelUtilizatori(idUtilizator, nume, prenume, email, parola, adresa, numarTelefon, conectat, statut,idRol);
                       
                        if (pass == user.parola)
                        {
                            user.statusConectare = "Conectare cu succes";
                        }
                        else
                        {
                            user.statusConectare = "Parola gresita";
                        }
                    }

                }
                else
                {
                    user = new ModelUtilizatori();
                    user.statusConectare = "Utilizator inexistent";
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return user;
        }
        public void updateLogin(int idUtilizator,bool conectat)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            try
            {
                cmd = new SqlCommand(NewQuery.loginUpdate, conn);
                cmd.Parameters.Add(new SqlParameter("id_utilizator", idUtilizator));
                cmd.Parameters.Add(new SqlParameter("conectat", conectat));
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }

        }
        public string checkIfConnected(int idUtilizator)
        {
            SqlConnection conn = db.initializare();
            //ModelUtilizatori user = null;
            string result = " ";
            bool conectat = true;
            try
            {
                cmd = new SqlCommand(NewQuery.checkIfisLogged, conn);
                cmd.Parameters.Add(new SqlParameter("id_utilizator", idUtilizator));
                reader = cmd.ExecuteReader();
              
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {

                        conectat = bool.Parse(reader["conectat"].ToString());

                        if (conectat )
                        {
                            result = "con";
                        }

                    }

                }
                else
                {
                    result = " Username not found";
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return result;
        }
        public string creeazaUser(ModelUtilizatori newAcc)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            string mesaj = " ";

            try
            {
                cmd = new SqlCommand(NewQuery.createAccount, conn);
                //cmd.Parameters.Add(new SqlParameter("idSpecializare", specializare.idSpecializare));
                cmd.Parameters.Add(new SqlParameter("nume", newAcc.nume));
                cmd.Parameters.Add(new SqlParameter("prenume", newAcc.prenume));
                cmd.Parameters.Add(new SqlParameter("email", newAcc.email));
                cmd.Parameters.Add(new SqlParameter("parola", newAcc.parola));
                cmd.Parameters.Add(new SqlParameter("adresa", newAcc.adresa));
                cmd.Parameters.Add(new SqlParameter("idRol", newAcc.idRol));
                cmd.Parameters.Add(new SqlParameter("conectat", newAcc.conectat));
                cmd.Parameters.Add(new SqlParameter("numarTelefon", newAcc.numarTelefon));


                if (cmd.ExecuteNonQuery() == 1)
                {
                    mesaj = "Cont creat cu succes";
                }




            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }

            return mesaj;
        }
        #endregion
        #region indexpages
        public int countAccounts()
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            int count = 0;
            try
            {
                cmd = new SqlCommand(NewQuery.countAccount, conn);
                count = (int)cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return count;
        }
        public int countCourse()
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            int count = 0;
            try
            {
                cmd = new SqlCommand(NewQuery.countCourse, conn);
                count = (int)cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return count;
        }
     /*   public List<ModelAnunturi> getAllAnnouncement()
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<ModelAnunturi> favs = new List<ModelAnunturi>();
            ModelAnunturi anunt = null;
            try
            {
                cmd = new SqlCommand(NewQuery.getAnnouncement, conn);
                // cmd.Parameters.Add(new SqlParameter("username", username));
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        int userID = Int32.Parse(reader["userID"].ToString());

                        string firstName = reader["nume"].ToString();
                        string lastName = reader["prenume"].ToString();
                        string mesaj = reader["mesaj"].ToString();
                        string data = reader["data"].ToString();

                        anunt = new ModelAnunturi(userID, firstName, lastName, mesaj, data);
                        favs.Add(anunt);
                        JavaScriptSerializer js = new JavaScriptSerializer();
                        //Context.Response.Write(js.Serialize(favs));
                    }

                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return favs;


        }*/
        #endregion
        #region userProfile
        public string updateData(ModelUtilizatori user)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            string testing1 = " ";

            try
            {
                cmd = new SqlCommand(NewQuery.updateAccount, conn);
                cmd.Parameters.Add(new SqlParameter("idUtilizator", user.idUtilizator));
                cmd.Parameters.Add(new SqlParameter("nume", user.nume));
                cmd.Parameters.Add(new SqlParameter("prenume", user.prenume));
                cmd.Parameters.Add(new SqlParameter("email", user.email));
                cmd.Parameters.Add(new SqlParameter("parola", user.parola));
                cmd.Parameters.Add(new SqlParameter("adresa", user.adresa));
                cmd.Parameters.Add(new SqlParameter("numarTelefon", user.numarTelefon));
            
                if (cmd.ExecuteNonQuery() == 1)
                {
                    testing1 = "Profile updated successfully";
                }
               
                    


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }

            return testing1;
        }
        #endregion
        #region Management Conturi
        public List<ModelUtilizatori> incarcaConturi()
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<ModelUtilizatori> listaConturi = new List<ModelUtilizatori>();
            ModelUtilizatori cont = null;
            try
            {
                cmd = new SqlCommand(NewQuery.incarcaConturi, conn);
                // cmd.Parameters.Add(new SqlParameter("username", username));
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        int idUtilizator = Int32.Parse(reader["id_utilizator"].ToString());
                        string nume = reader["nume"].ToString();
                        string prenume = reader["prenume"].ToString();
                        string email = reader["email"].ToString();
                        string parola = reader["parola"].ToString();
                        string adresa = reader["adresa"].ToString();
                        string numarTelefon = reader["nr_telefon"].ToString();
                        bool conectat = bool.Parse(reader["conectat"].ToString());
                        string statut = reader["statut"].ToString();
                        int idRol = Int32.Parse(reader["id_rol"].ToString());

                        cont = new ModelUtilizatori(idUtilizator,nume,prenume,email,parola,adresa,numarTelefon,conectat,statut,idRol);
                        listaConturi.Add(cont);


                    }

                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return listaConturi;


        }
        public ModelUtilizatori detaliiCont(int idUtilizator)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<ModelUtilizatori> listaConturi = new List<ModelUtilizatori>();
            ModelUtilizatori cont = null;
            try
            {
                cmd = new SqlCommand(NewQuery.detaliiCont, conn);
                 cmd.Parameters.Add(new SqlParameter("idUtilizator", idUtilizator));
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        idUtilizator = Int32.Parse(reader["id_utilizator"].ToString());
                        string nume = reader["nume"].ToString();
                        string prenume = reader["prenume"].ToString();
                        string email = reader["email"].ToString();
                        string parola = reader["parola"].ToString();
                        string adresa = reader["adresa"].ToString();
                        string numarTelefon = reader["nr_telefon"].ToString();
                       bool conectat = bool.Parse(reader["conectat"].ToString());
                        string statut = reader["statut"].ToString();
                        int idRol = Int32.Parse(reader["id_rol"].ToString());
                        cont = new ModelUtilizatori(idUtilizator, nume, prenume, email, parola, adresa, numarTelefon, conectat, statut,idRol);

                        listaConturi.Add(cont);


                    }

                }
                else
                {

                }
                    
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return cont;


        }
        public void stergeCont(DeleteModel cont)
        {

            SqlConnection conn = db.initializare();
            SqlCommand cmd;


            try
            {
                cmd = new SqlCommand(NewQuery.stergeCont, conn);
                cmd.Parameters.Add(new SqlParameter("id_utilizator", cont.idUtilizator));

                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }



        }
        public string updateAccountsAdmin(ModelUtilizatori user)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            string testing1 = " ";

            try
            {
                cmd = new SqlCommand(NewQuery.adminUpdateAccount, conn);
                cmd.Parameters.Add(new SqlParameter("id_utilizator", user.idUtilizator));
                cmd.Parameters.Add(new SqlParameter("nume", user.nume));
                cmd.Parameters.Add(new SqlParameter("prenume", user.prenume));
                cmd.Parameters.Add(new SqlParameter("email", user.email));
                cmd.Parameters.Add(new SqlParameter("parola", user.parola));
                cmd.Parameters.Add(new SqlParameter("adresa", user.adresa));
                cmd.Parameters.Add(new SqlParameter("numarTelefon", user.numarTelefon));
                cmd.Parameters.Add(new SqlParameter("conectat", user.conectat));
               
                
     

                

                if (cmd.ExecuteNonQuery() == 1)
                {
                    testing1 = "Profile updated successfully";
                }




            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }

            return testing1;
        }
        #endregion
        #region Management Specializari
        public string creeazaSpecializare(ModelSpecializari specializare)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            string mesaj = " ";

            try
            {
                cmd = new SqlCommand(NewQuery.creeazaSpecializare, conn);
                //cmd.Parameters.Add(new SqlParameter("idSpecializare", specializare.idSpecializare));
                cmd.Parameters.Add(new SqlParameter("numeSpecializare", specializare.numeSpecializare));
                cmd.Parameters.Add(new SqlParameter("locuriDisponibile", specializare.locuriDisponibile));
                cmd.Parameters.Add(new SqlParameter("locuriOcupate", specializare.locuriOcupate));
                cmd.Parameters.Add(new SqlParameter("aniStudiu", specializare.aniStudiu));


                if (cmd.ExecuteNonQuery() == 1)
                {
                    mesaj = "Specializare creata cu succes";
                }




            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }

            return mesaj;
        }
        public List<ModelSpecializari> incarcaSpecializari()
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<ModelSpecializari> listaSpecializari = new List<ModelSpecializari>();
            ModelSpecializari specializare = null;
            try
            {
                cmd = new SqlCommand(NewQuery.incarcaSpecializari, conn);
                // cmd.Parameters.Add(new SqlParameter("username", username));
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        int idSpecializare = Int32.Parse(reader["id_specializare"].ToString());

                        string numeSpecializare = reader["nume_specializare"].ToString();
                        int locuriOcupate = Int32.Parse(reader["locuri_ocupate"].ToString());
                        int locuriDisponibile = Int32.Parse(reader["locuri_disponibile"].ToString());
                        int aniStudiu = Int32.Parse(reader["ani_studiu"].ToString());

                        specializare = new ModelSpecializari(idSpecializare, numeSpecializare, locuriDisponibile, locuriOcupate, aniStudiu);
                        listaSpecializari.Add(specializare);
                       
                     
                    }

                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return listaSpecializari;


        }
        public void stergeSpecializare(ModelSpecializari spc)
        {

            SqlConnection conn = db.initializare();
            SqlCommand cmd;


            try
            {
                cmd = new SqlCommand(NewQuery.stergeSpecializari, conn);
                cmd.Parameters.Add(new SqlParameter("id_specializare",spc.idSpecializare));

                cmd.ExecuteNonQuery();


            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }



        }
        public ModelSpecializari detaliiSpecializare(int idSpecializare)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<ModelSpecializari> listaSpecializari = new List<ModelSpecializari>();
            ModelSpecializari specializare = null;
            try
            {
                cmd = new SqlCommand(NewQuery.detaliiSpecializare, conn);
                cmd.Parameters.Add(new SqlParameter("id_specializare", idSpecializare));
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        idSpecializare = Int32.Parse(reader["id_specializare"].ToString());
                        string numeSpecializare = reader["nume_specializare"].ToString();
                        int locuriDisponibile = Int32.Parse(reader["locuri_disponibile"].ToString());
                        int locuriOcupate = Int32.Parse(reader["locuri_ocupate"].ToString());
                        int aniStudiu = Int32.Parse(reader["ani_studiu"].ToString());

    
 

                        specializare = new ModelSpecializari(idSpecializare, numeSpecializare, locuriDisponibile, locuriOcupate, aniStudiu);
                        listaSpecializari.Add(specializare);


                    }

                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return specializare;


        }
        public string modificaSpecialziare(ModelSpecializari specializare)
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            string mesaj = " ";

            try
            {
                cmd = new SqlCommand(NewQuery.modificaSpecializari, conn);
                cmd.Parameters.Add(new SqlParameter("idSpecializare", specializare.idSpecializare));
                cmd.Parameters.Add(new SqlParameter("nume_specializare", specializare.numeSpecializare));
                cmd.Parameters.Add(new SqlParameter("locuri_disponibile", specializare.locuriDisponibile));
                cmd.Parameters.Add(new SqlParameter("locuri_ocupate", specializare.locuriOcupate));
                cmd.Parameters.Add(new SqlParameter("ani_studiu", specializare.aniStudiu));
               




                if (cmd.ExecuteNonQuery() == 1)
                {
                    mesaj = "Specializare modificata cu success";
                }
                else
                {
                    mesaj = "Nu se poate modifica specializarea";
                }




            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }

            return mesaj;
        }
        #endregion
        #region management membrii specializari
        public List<ModelStudenti> getProfileMembers()
        {
            SqlConnection conn = db.initializare();
            SqlCommand cmd;
            List<ModelStudenti> listaMembrii = new List<ModelStudenti>();
            ModelStudenti membrii = null;
            try
            {
                cmd = new SqlCommand(NewQuery.incarcaMembriiSpecializari, conn);
               
                reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {


                    while (reader.Read())
                    {

                        int id = Int32.Parse(reader["id"].ToString());
                        int idSpecializare = Int32.Parse(reader["id_specializare"].ToString());
                        int idUtilizator = Int32.Parse(reader["id_utilizator"].ToString());
                        int nrCredite = Int32.Parse(reader["nr_credite"].ToString());
                        int anStudiu = Int32.Parse(reader["an_studiu"].ToString());
                        string nume = reader["nume"].ToString();
                        string prenume = reader["prenume"].ToString();
                        string numeSpecializare = reader["nume_specializare"].ToString();
                        membrii = new ModelStudenti(id,idSpecializare, idUtilizator,nrCredite,anStudiu,nume,prenume, numeSpecializare);
                        listaMembrii.Add(membrii);


                    }

                }
                else
                {

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

                conn.Dispose();
                conn.Close();
            }
            return listaMembrii;


        }
        #endregion
       
        







    }
}