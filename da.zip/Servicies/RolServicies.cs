﻿using Office03.Models;
using Office03.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using static Office03.Models.ModelSpecializari;
using static Office03.Models.ModelUtilizatori;

namespace Office03.Servicies
{
    public class RolServicies
    {
        public static List<ModelRoluri> getAllRoles()
        {
            {
                RoleRepository up = new RoleRepository();
                List<ModelRoluri> rolesList = null;
                try
                {
                    rolesList = up.getAllRoles();
                }
                catch (Exception ex)
                {
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return rolesList;
            }
        }
    }
}