﻿using Office03.Models;
using Office03.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using static Office03.Models.TeacherModel;

namespace Office03.Servicies
{
    public class TeacherServicies
    {
        public static List<TeacherModel> loadAllTeachers()
        {
            {
                TeacherRepository up = new TeacherRepository();
                List<TeacherModel> teacherList = null;
                try
                {


                    teacherList = up.loadAllTeachers();
                }
                catch (Exception ex)
                {
                   
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return teacherList;
            }
        }
        public void deleteTeacher(TeacherModel teacher)
        {

            TeacherRepository up = new TeacherRepository();
            up.deleteTeacher(teacher);

        }
        public string setTeacherCourse(SetTeacherCourse teacher)
        {

            TeacherRepository up = new TeacherRepository();
            string mesaj = up.setTeacherCourse(teacher);
            return mesaj;

        }
        public static List<CourseModel> getAllCourses()
        {
            {
                TeacherRepository up = new TeacherRepository();
                List<CourseModel> courseList = null;
                try
                {
                    courseList = up.getAllCourses();
                }
                catch (Exception ex)
                {
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return courseList;
            }
        }
        public static TeacherModel teacherDetails(int idUtilizator)
        {
            {
                TeacherRepository up = new TeacherRepository();
                TeacherModel teacher = null;
                try
                {


                    teacher = up.teacherDetails(idUtilizator);
                }
                catch (Exception ex)
                {
                    //mesajele de eroare se logheaz in baza de date intr-o tabela de log-uri
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return teacher;
            }
        }
    }
}