﻿using Office03.Models;
using Office03.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using static Office03.Models.ModelSpecializari;
using static Office03.Models.ModelUtilizatori;

namespace Office03.Servicies
{
    public class UServicies
    {
       
        //public static List<ModelAnunturi> getAllAnnouncement()
        //{
        //    {
        //        URepository up = new URepository();
        //        List<ModelAnunturi> favs = null;
        //        try
        //        {


        //            favs = up.getAllAnnouncement();
        //        }
        //        catch (Exception ex)
        //        {
        //            //mesajele de eroare se logheaz in baza de date intr-o tabela de log-uri
        //            var mesajEroare = ex.Message + "-" + ex.InnerException; ;
        //        }
        //        return favs;
        //    }
        //}
        #region Conectare/Deconectare/Inregistrare
        public static ModelUtilizatori userLogin(string email, string pass)
        {

            URepository up = new URepository();
            ModelUtilizatori user = up.checkUserLogin(email, pass);
            if (user.statusConectare == "Conectare cu succes")
            {
                up.updateLogin(user.idUtilizator, true);

            }
            return user;
        }
        public void checkIfConnected(int idUtilizator)
        {
            URepository us = new URepository();
            string result = us.checkIfConnected(idUtilizator);
            if (result == "con")
            {
                us.updateLogin(idUtilizator, false);

            }

        }
        public string creeazaUser(ModelUtilizatori newAcc)
        {
            URepository spec = new URepository();
            string mesaj = spec.creeazaUser(newAcc);
            return mesaj;
        }
        #endregion
        #region indexpages
        public int countAccounts(int count)
        {
            URepository us = new URepository();
            count = us.countAccounts();
            return count;

        }
        public int countCourse(int count)
        {
            URepository us = new URepository();
            count = us.countCourse();
            return count;

        }
        #endregion
        #region userProfile
        public string updateData(ModelUtilizatori user)
        {

            URepository up = new URepository();
            string testing1 = up.updateData(user);
            return testing1;

        }
        #endregion
        #region Management Specializari
        public string creeazaSpecializare(ModelSpecializari specializare)
        {
            URepository spec = new URepository();
            string mesaj = spec.creeazaSpecializare(specializare);
            return mesaj;
        }
        public static List<ModelSpecializari> incarcaSpecializare()
        {
            {
                URepository up = new URepository();
                List<ModelSpecializari> listaSpecializari = null;
                try
                {


                    listaSpecializari = up.incarcaSpecializari();
                }
                catch (Exception ex)
                {
                    //mesajele de eroare se logheaz in baza de date intr-o tabela de log-uri
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return listaSpecializari;
            }
        }
        public  void stergeSpecializare(ModelSpecializari spc)
        { 

            URepository up = new URepository();
            up.stergeSpecializare(spc);

        }
        public static ModelSpecializari detaliiSpecializari(int idSpecializare)
        {
            {
                URepository up = new URepository();
                ModelSpecializari listaSpecializare = null;
                try
                {


                    listaSpecializare = up.detaliiSpecializare(idSpecializare);
                }
                catch (Exception ex)
                {
                    //mesajele de eroare se logheaz in baza de date intr-o tabela de log-uri
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return listaSpecializare;
            }
        }
        public string modificaSpecializare(ModelSpecializari specializare)
        {

            URepository up = new URepository();
            string mesaj = up.modificaSpecialziare(specializare);
            return mesaj;

        }
        #endregion
        #region Management conturi
        public static List<ModelUtilizatori> incarcaConturi()
        {
            {
                URepository up = new URepository();
                List<ModelUtilizatori> listaConturi = null;
                try
                {


                    listaConturi = up.incarcaConturi();
                }
                catch (Exception ex)
                {
                    //mesajele de eroare se logheaz in baza de date intr-o tabela de log-uri
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return listaConturi;
            }
        }
        public static ModelUtilizatori detaliiCont(int idUtilizator)
        {
            {
                URepository up = new URepository();
                ModelUtilizatori listaConturi = null;
                try
                {


                    listaConturi = up.detaliiCont(idUtilizator);
                }
                catch (Exception ex)
                {
                    //mesajele de eroare se logheaz in baza de date intr-o tabela de log-uri
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return listaConturi;
            }
        }
        public void stergeCont(DeleteModel cont)
        {

            URepository up = new URepository();
            up.stergeCont(cont);

        }
        public string updateAccountsAdmin(ModelUtilizatori user)
        {

            URepository up = new URepository();
            string testing1 = up.updateAccountsAdmin(user);
            return testing1;

        }
        #endregion
        #region management membrii specializari
        public static List<ModelStudenti> getProfileMembers()
        {
            {
                URepository up = new URepository();
                List<ModelStudenti> listaMembrii = null;
                try
                {


                    listaMembrii = up.getProfileMembers();
                }
                catch (Exception ex)
                {
                    //mesajele de eroare se logheaz in baza de date intr-o tabela de log-uri
                    var mesajEroare = ex.Message + "-" + ex.InnerException; ;
                }
                return listaMembrii;
            }
        }
        #endregion
    }
}